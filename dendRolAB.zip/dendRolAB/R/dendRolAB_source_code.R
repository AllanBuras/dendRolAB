###a function to conveniently generate master chronos per tree


chron.by.stem<-function(rwl,str.id1,str.id2)
	{
	IDS<-substr(colnames(rwl),str.id1,str.id2)
	AV.RWL<-matrix(nrow=nrow(rwl),ncol=length(unique(IDS)))
	for(i in 1:ncol(AV.RWL))
		{
		AV.RWL[,i]<-chron(as.matrix(rwl[,which(IDS==unique(IDS)[i])]),biweight=F)[,1]
		}
	rownames(AV.RWL)<-rownames(rwl)
	colnames(AV.RWL)<-unique(IDS)
	return(as.data.frame(AV.RWL))
	}

###meta-function needed for PCGA

.polar.trans<-function(matrix)
	{
	POL_MAT<-matrix(nrow=nrow(matrix),ncol=2)
	for(i in 1:nrow(matrix))
		{
		POL_MAT[i,2]<-dist(rbind(c(0,0),matrix[i,1:2]),method="euclidean")
		POL_MAT[i,1]<-atan2(matrix[i,2],matrix[i,1])
		}
	return(POL_MAT)
	}

###code for PCGA, provide this function with an rwl-data.frame


.PrCoGrAn<-function(DATA)
	{
	CI.DATA<-common.interval(DATA)
	PCA<-prcomp(CI.DATA,scale=T)
	IMP<-summary(PCA)$imp[,1:4]
	POL_COORD<-.polar.trans(PCA$rot[,1:2])
	POL_COORD2<-.polar.trans(-PCA$rot[,1:2])
	if(max(dist(POL_COORD[,1]))>max(dist(POL_COORD2[,1])))
		{
		POL_COORD<-POL_COORD2
		PCA$rot<--PCA$rot
		}
	list(pca=PCA,imp=IMP,rank=order(POL_COORD[,1]),pol.coord=POL_COORD,pop=DATA[,colnames(CI.DATA)],period=rownames(CI.DATA))
	}

pcga<-function(DATA)UseMethod("PCGA")

PCGA.default<-function(DATA)
	{
	result<-.PrCoGrAn(DATA)
	class(result)<-"PCGA"
	result
	}

plot.PCGA<-function(x,col.vec=NULL,title=NULL,lab.size=1.5,axis.size=1.5)
	{
	plot(0,0,type="n",xlim=range(-c(x$pca$rot[,1],x$pca$rot[,2]),c(x$pca$rot[,1],x$pca$rot[,2])),
	ylim=range(-c(x$pca$rot[,1],x$pca$rot[,2]),c(x$pca$rot[,1],x$pca$rot[,2])),xlab=round(x$imp[2,1],2),ylab=round(x$imp[2,2],2),
	cex.lab=lab.size,cex.axis=axis.size,main=title)
	if(length(col.vec)==0)
		{
		for(i in 1:nrow(x$pca$rot))
			{
			arrows(0,0,x$pca$rot[x$rank[i],1],x$pca$rot[x$rank[i],2],col=hsv(i/(nrow(x$pca$rot)*1.2)),lwd=2,length=0.1)
			}
		}
	if(length(col.vec)>0)
		{
		for(i in 1:nrow(x$pca$rot))
			{
			arrows(0,0,x$pca$rot[x$rank[i],1],x$pca$rot[x$rank[i],2],col=col.vec[x$rank[i]],lwd=2,length=0.1)
			}
		}
	}


identRank<-function(pcga.obj)
	{
	plot(pcga.obj)
	print("please select tree by clicking on the head of the loading-arrows")
	LOC<-locator(1)
	DIST<-vector(mode="numeric")
	for(i in 1:nrow(pcga.obj$pca$rot[,1:2]))
		{
		DIST[i]<-dist(rbind(LOC,pcga.obj$pca$rot[pcga.obj$rank[i],1:2]))
		}
	text(x=LOC[1],y=LOC[2],labels=which.min(DIST),pos=4)
	text(x=pcga.obj$pca$rot[pcga.obj$rank[c(1,length(pcga.obj$rank))],1],
	y=pcga.obj$pca$rot[pcga.obj$rank[c(1,length(pcga.obj$rank))],2],labels=c(1,length(pcga.obj$rank)),pos=4)
	return(which.min(DIST))
	}


